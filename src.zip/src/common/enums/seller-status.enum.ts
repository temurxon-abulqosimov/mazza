export enum SellerStatus {
    PENDING = 'pending',
    APPROVED = 'approved',
    REJECTED = 'rejected',
    BLOCKED = 'blocked',
  }
  