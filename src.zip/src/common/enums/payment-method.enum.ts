export enum PaymentMethod {
    CASH = 'cash',
    CARD = 'card',
    CLICK = 'click',
    PAYME = 'payme',
  }
  