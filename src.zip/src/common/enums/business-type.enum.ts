export enum BusinessType {
    CAFE = 'cafe',
    RESTAURANT = 'restaurant',
    MARKET = 'market',
    PHARMACY = 'pharmacy',
    BAKERY = 'bakery',
    OTHER = 'other',
  }
  