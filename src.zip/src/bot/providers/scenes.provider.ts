// src/bot/providers/scenes.provider.ts
import { Scenes } from 'telegraf';
import { BotContext } from '../bot.context';
import { UserRegistrationWizard } from '../scenes/user-registration.scene';
import { UsersService } from '../../users/users.service';

export const ScenesProvider = {
  provide: 'SCENES_STAGE',
  inject: [UsersService],
  useFactory: (usersService: UsersService) => {
    const scene = new UserRegistrationWizard(usersService);
    const stage = new Scenes.Stage<BotContext>([scene]);
    return stage;
  },
};
