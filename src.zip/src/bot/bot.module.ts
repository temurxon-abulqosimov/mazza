// bot/bot.module.ts
import { Module } from '@nestjs/common';
import { TelegrafModule } from 'nestjs-telegraf';
import { BotUpdate } from './bot.update';
import { ScenesProvider } from './providers/scenes.provider';
import { Scenes } from 'telegraf';
import { BotContext } from './bot.context';
import { envVariables } from 'src/config/env.variables';
import { BotScenesModule } from './scenes/scenes.module';

@Module({
    imports: [
        BotScenesModule,
        TelegrafModule.forRootAsync({
            imports: [BotScenesModule],
            inject: ['SCENES_STAGE'],
            useFactory: async (stage: Scenes.Stage<BotContext>) => ({
                token: envVariables.TELEGRAM_BOT_TOKEN!,
                middlewares: [stage.middleware()],
            }),
        }),
    ],
    providers: [BotUpdate, ScenesProvider],
    exports: ['SCENES_STAGE'],
})
export class BotModule { }
