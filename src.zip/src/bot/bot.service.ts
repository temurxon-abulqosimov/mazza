// src/bot/bot.service.ts
import { Injectable, OnModuleInit } from '@nestjs/common';
import { InjectBot } from 'nestjs-telegraf';
import { Telegraf, session, Scenes } from 'telegraf';
import { BotContext } from './bot.context';
import { UserRegistrationWizard } from './scenes/user-registration.scene';

@Injectable()
export class BotService implements OnModuleInit {
  constructor(
    @InjectBot() private readonly bot: Telegraf<BotContext>,
    private readonly registrationWizard: UserRegistrationWizard,
  ) {}

  onModuleInit() {
    const stage = new Scenes.Stage<BotContext>([this.registrationWizard]);
    this.bot.use(session());
    this.bot.use(stage.middleware());
    console.log('✅ Scene stage middleware initialized');
  }
}
