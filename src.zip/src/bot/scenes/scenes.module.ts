import { Module } from '@nestjs/common';
import { UserRegistrationWizard } from './user-registration.scene';
import { UsersModule } from 'src/users/users.module';
import { ScenesProvider } from '../providers/scenes.provider';

@Module({
  imports: [UsersModule],
  providers: [UserRegistrationWizard, ScenesProvider],
  exports: [UserRegistrationWizard,  ScenesProvider],
})
export class BotScenesModule {}
