export class CreateProductDto {}
